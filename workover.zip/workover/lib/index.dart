// Export pages
export '/pages/login/login_widget.dart' show LoginWidget;
export '/pages/signup/signup_widget.dart' show SignupWidget;
export '/pages/createtask/createtask_widget.dart' show CreatetaskWidget;
export '/pages/forgotpassword/forgotpassword_widget.dart'
    show ForgotpasswordWidget;
export '/pages/alltasks/alltasks_widget.dart' show AlltasksWidget;
export '/pages/handover/handover_widget.dart' show HandoverWidget;
export '/pages/managersdashboard/managersdashboard_widget.dart'
    show ManagersdashboardWidget;
export '/pages/userlist/userlist_widget.dart' show UserlistWidget;
export '/pages/userfronofficelist/userfronofficelist_widget.dart'
    show UserfronofficelistWidget;
export '/pages/userfandblist/userfandblist_widget.dart'
    show UserfandblistWidget;
export '/pages/userhousekeepinglist/userhousekeepinglist_widget.dart'
    show UserhousekeepinglistWidget;
export '/pages/userkitchenlist/userkitchenlist_widget.dart'
    show UserkitchenlistWidget;
export '/pages/settingstaff/settingstaff_widget.dart' show SettingstaffWidget;
export '/pages/settingmanager/settingmanager_widget.dart'
    show SettingmanagerWidget;
export '/pages/downloadreport/downloadreport_widget.dart'
    show DownloadreportWidget;
export '/pages/remindernewtasklist/remindernewtasklist_widget.dart'
    show RemindernewtasklistWidget;
export '/pages/empdashboard/empdashboard_widget.dart' show EmpdashboardWidget;
