import '/flutter_flow/flutter_flow_util.dart';
import 'settingstaff_widget.dart' show SettingstaffWidget;
import 'package:flutter/material.dart';

class SettingstaffModel extends FlutterFlowModel<SettingstaffWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
