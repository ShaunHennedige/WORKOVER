import '/flutter_flow/flutter_flow_util.dart';
import 'settingmanager_widget.dart' show SettingmanagerWidget;
import 'package:flutter/material.dart';

class SettingmanagerModel extends FlutterFlowModel<SettingmanagerWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
