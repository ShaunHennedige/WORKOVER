import '/flutter_flow/flutter_flow_util.dart';
import 'selectteam_widget.dart' show SelectteamWidget;
import 'package:flutter/material.dart';

class SelectteamModel extends FlutterFlowModel<SelectteamWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
